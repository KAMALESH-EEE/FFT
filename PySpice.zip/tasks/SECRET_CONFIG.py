SSH_CONFIG = {
    'ssh_user': 'apache-rsync',
    'ssh_host': 'ovh-vps',
    'ssh_port': '54321',
    'ssh_path': '/var/www/pyspice',
}
