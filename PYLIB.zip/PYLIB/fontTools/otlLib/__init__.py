"""OpenType Layout-related functionality."""
